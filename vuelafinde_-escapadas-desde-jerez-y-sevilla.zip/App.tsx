
import React, { useState, useEffect, useCallback } from 'react';
import { fetchWeekendEscapes } from './services/geminiService';
import Header from './components/Header';
import FlightCard from './components/FlightCard';
import { SearchState, FlightOption } from './types';
import { format, addDays, nextFriday, nextMonday } from 'date-fns';
import { es } from 'date-fns/locale';

const App: React.FC = () => {
  const [state, setState] = useState<SearchState>({
    loading: false,
    results: [],
    error: null,
    lastUpdated: new Date().toISOString(),
    targetWeekend: '',
  });

  const [groundingSources, setGroundingSources] = useState<any[]>([]);
  const [originFilter, setOriginFilter] = useState<'SVQ' | 'XRY' | 'BOTH'>('BOTH');

  const calculateWeekendDates = useCallback(() => {
    const today = new Date();
    const friday = nextFriday(today);
    const monday = addDays(friday, 3);
    
    return {
      friday: format(friday, 'yyyy-MM-dd'),
      monday: format(monday, 'yyyy-MM-dd'),
      label: `${format(friday, "d MMM", { locale: es })} - ${format(monday, "d MMM", { locale: es })}`
    };
  }, []);

  const handleSearch = useCallback(async () => {
    const dates = calculateWeekendDates();
    setState(prev => ({ ...prev, loading: true, error: null, targetWeekend: dates.label }));

    try {
      const data = await fetchWeekendEscapes(originFilter, dates.friday, dates.monday);
      setState(prev => ({ 
        ...prev, 
        loading: false, 
        results: data.flights,
        lastUpdated: new Date().toISOString()
      }));
      setGroundingSources(data.sources);
    } catch (err) {
      setState(prev => ({ 
        ...prev, 
        loading: false, 
        error: 'No pudimos conectar con el radar de vuelos. Intenta de nuevo.' 
      }));
    }
  }, [calculateWeekendDates, originFilter]);

  useEffect(() => {
    handleSearch();
  }, [originFilter]);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col max-w-md mx-auto shadow-2xl overflow-x-hidden">
      <Header 
        loading={state.loading} 
        onRefresh={handleSearch} 
        origin={originFilter} 
        setOrigin={setOriginFilter}
      />
      
      <main className="flex-1 px-4 py-6 pb-24">
        <div className="mb-6">
          <div className="flex items-end justify-between px-1">
            <div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Fin de semana</p>
              <h2 className="text-xl font-black text-slate-800">{state.targetWeekend}</h2>
            </div>
            <div className="text-right">
              <p className="text-[10px] font-black text-violet-500 uppercase tracking-widest">Encontrados</p>
              <p className="text-xl font-black text-slate-800">{state.results.length}</p>
            </div>
          </div>
        </div>

        {state.error && (
          <div className="bg-red-50 border border-red-100 p-6 rounded-[2rem] flex flex-col items-center text-center gap-2 mb-8">
            <div className="w-12 h-12 bg-red-100 text-red-500 rounded-full flex items-center justify-center text-xl mb-2">
              <i className="fa-solid fa-triangle-exclamation"></i>
            </div>
            <p className="font-bold text-red-800">{state.error}</p>
            <button 
              onClick={handleSearch}
              className="mt-2 text-xs font-black text-red-500 uppercase tracking-wider"
            >
              Reintentar
            </button>
          </div>
        )}

        {state.loading ? (
          <div className="space-y-6">
            {[1, 2, 3].map(i => (
              <div key={i} className="bg-white rounded-[2.5rem] p-6 border border-slate-100 animate-pulse">
                <div className="h-4 bg-slate-100 rounded-full w-24 mb-4"></div>
                <div className="h-8 bg-slate-100 rounded-full w-48 mb-6"></div>
                <div className="h-20 bg-slate-50 rounded-3xl mb-6"></div>
                <div className="grid grid-cols-3 gap-2">
                  <div className="h-12 bg-slate-50 rounded-2xl"></div>
                  <div className="h-12 bg-slate-50 rounded-2xl"></div>
                  <div className="h-12 bg-slate-50 rounded-2xl"></div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-1">
            {state.results.map((flight, idx) => (
              <FlightCard key={idx} flight={flight} />
            ))}
            
            {state.results.length === 0 && !state.error && (
              <div className="text-center py-20 opacity-30">
                <i className="fa-solid fa-plane-slash text-4xl mb-4"></i>
                <p className="font-bold">No hay vuelos disponibles</p>
              </div>
            )}
          </div>
        )}

        {groundingSources.length > 0 && (
          <div className="mt-8 px-2">
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Datos extraídos de</h3>
            <div className="flex flex-wrap gap-2">
              {groundingSources.slice(0, 4).map((source, idx) => (
                <a 
                  key={idx} 
                  href={source.web?.uri} 
                  target="_blank" 
                  className="px-4 py-2 bg-white border border-slate-100 rounded-2xl text-[10px] font-bold text-slate-500 hover:text-violet-600 transition-colors shadow-sm"
                >
                  {source.web?.title?.substring(0, 15)}...
                </a>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Bottom Nav Simulation */}
      <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white/90 backdrop-blur-xl border-t border-slate-100 flex items-center justify-around h-16 px-6 z-50">
        <button className="flex flex-col items-center text-violet-600">
          <i className="fa-solid fa-house-chimney text-lg"></i>
          <span className="text-[9px] font-bold mt-1 uppercase">Explorar</span>
        </button>
        <button className="flex flex-col items-center text-slate-300">
          <i className="fa-solid fa-heart text-lg"></i>
          <span className="text-[9px] font-bold mt-1 uppercase">Favoritos</span>
        </button>
        <button className="flex flex-col items-center text-slate-300">
          <i className="fa-solid fa-user text-lg"></i>
          <span className="text-[9px] font-bold mt-1 uppercase">Perfil</span>
        </button>
      </nav>
    </div>
  );
};

export default App;
