
import React from 'react';
import { FlightOption } from '../types';

interface FlightCardProps {
  flight: FlightOption;
}

const FlightCard: React.FC<FlightCardProps> = ({ flight }) => {
  return (
    <div className="bg-white rounded-[2.5rem] p-6 mb-6 border border-slate-100 shadow-[0_8px_30px_rgb(0,0,0,0.04)] active:scale-[0.98] transition-transform">
      <div className="flex justify-between items-start mb-4">
        <div className="flex-1">
          <span className="inline-block px-3 py-1 bg-violet-50 text-violet-600 text-[10px] font-black uppercase rounded-full mb-2">
            Mejor Oferta
          </span>
          <h2 className="text-2xl font-black text-slate-800 leading-tight">{flight.destino}</h2>
          <p className="text-slate-400 text-sm font-medium">{flight.descripcion_destino}</p>
        </div>
        <div className="text-right">
          <p className="text-2xl font-black text-violet-600">{flight.precio}€</p>
          <p className="text-[10px] text-slate-400 font-bold uppercase">Total I/V</p>
        </div>
      </div>

      <div className="bg-slate-50 rounded-3xl p-4 flex items-center justify-between mb-6">
        <div className="flex flex-col items-center">
          <span className="text-[10px] font-bold text-slate-400 uppercase">Ida</span>
          <span className="text-sm font-black text-slate-700">{flight.salida}</span>
          <span className="text-[10px] text-slate-400">{flight.origen}</span>
        </div>
        <div className="flex-1 flex flex-col items-center px-4">
          <div className="w-full h-[2px] bg-slate-200 relative">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-slate-50 px-2">
              <i className="fa-solid fa-plane text-[10px] text-slate-300"></i>
            </div>
          </div>
          <span className="text-[9px] font-bold text-slate-300 mt-1 uppercase tracking-widest">{flight.aerolinea}</span>
        </div>
        <div className="flex flex-col items-center">
          <span className="text-[10px] font-bold text-slate-400 uppercase">Vuelta</span>
          <span className="text-sm font-black text-slate-700">{flight.regreso}</span>
          <span className="text-[10px] text-slate-400">{flight.destino.substring(0, 3).toUpperCase()}</span>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2">
        <div className="bg-blue-50/50 p-3 rounded-2xl flex flex-col items-center justify-center">
          <i className="fa-solid fa-temperature-half text-blue-500 text-xs mb-1"></i>
          <span className="text-[11px] font-black text-slate-700">{flight.temperatura}</span>
          <span className="text-[8px] text-blue-400 uppercase font-bold">{flight.clima}</span>
        </div>
        <div className="bg-emerald-50/50 p-3 rounded-2xl flex flex-col items-center justify-center">
          <i className="fa-solid fa-bed text-emerald-500 text-xs mb-1"></i>
          <span className="text-[11px] font-black text-slate-700">{flight.coste_alojamiento}</span>
          <span className="text-[8px] text-emerald-400 uppercase font-bold">Hotel 3*</span>
        </div>
        <div className="bg-orange-50/50 p-3 rounded-2xl flex flex-col items-center justify-center">
          <i className="fa-solid fa-utensils text-orange-500 text-xs mb-1"></i>
          <span className="text-[11px] font-black text-slate-700">{flight.coste_restauracion}</span>
          <span className="text-[8px] text-orange-400 uppercase font-bold">Comida/Cena</span>
        </div>
      </div>
    </div>
  );
};

export default FlightCard;
