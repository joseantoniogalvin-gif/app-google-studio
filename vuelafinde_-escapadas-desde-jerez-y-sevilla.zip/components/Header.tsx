
import React from 'react';

interface HeaderProps {
  loading: boolean;
  onRefresh: () => void;
  origin: 'SVQ' | 'XRY' | 'BOTH';
  setOrigin: (origin: 'SVQ' | 'XRY' | 'BOTH') => void;
}

const Header: React.FC<HeaderProps> = ({ loading, onRefresh, origin, setOrigin }) => {
  return (
    <header className="bg-white border-b border-slate-100 sticky top-0 z-50 px-4 pt-4 pb-2">
      <div className="max-w-md mx-auto">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-violet-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-violet-200">
              <i className="fa-solid fa-plane-departure"></i>
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900 tracking-tight">VuelaFinde</h1>
              <p className="text-[10px] text-violet-600 font-bold uppercase tracking-widest">Escapadas Pro</p>
            </div>
          </div>
          <button 
            onClick={onRefresh}
            disabled={loading}
            className="w-10 h-10 flex items-center justify-center rounded-full bg-slate-50 text-slate-600 active:bg-slate-200 transition-colors"
          >
            <i className={`fa-solid fa-rotate-right ${loading ? 'animate-spin' : ''}`}></i>
          </button>
        </div>

        <div className="flex bg-slate-100 p-1 rounded-2xl">
          {(['BOTH', 'SVQ', 'XRY'] as const).map((opt) => (
            <button
              key={opt}
              onClick={() => setOrigin(opt)}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                origin === opt 
                  ? 'bg-white text-violet-600 shadow-sm' 
                  : 'text-slate-500'
              }`}
            >
              {opt === 'BOTH' ? 'Todos' : opt === 'SVQ' ? 'Sevilla' : 'Jerez'}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
};

export default Header;
