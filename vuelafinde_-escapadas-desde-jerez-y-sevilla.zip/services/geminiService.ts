
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function fetchWeekendEscapes(origin: 'SVQ' | 'XRY' | 'BOTH', nextFriday: string, nextMonday: string) {
  const model = 'gemini-3-flash-preview';
  
  const originText = origin === 'BOTH' ? 'Sevilla (SVQ) o Jerez (XRY)' : (origin === 'SVQ' ? 'Sevilla (SVQ)' : 'Jerez (XRY)');

  const prompt = `
    Actúa como un motor de búsqueda de viajes en tiempo real.
    Busca los 5 vuelos de ida y vuelta más baratos desde ${originText}.
    
    CRITERIOS OBLIGATORIOS:
    - Salida: Viernes ${nextFriday} después de las 18:00.
    - Regreso: Lunes ${nextMonday} antes de las 24:00.
    - Estancia mínima: 48 horas.
    - Destinos: Ciudades atractivas en España o Europa.

    RESPUESTA REQUERIDA:
    Debes devolver un bloque de código JSON válido con una lista de 5 objetos. No añadas texto fuera del JSON.
    Cada objeto debe tener esta estructura exacta:
    {
      "destino": "Nombre Ciudad",
      "origen": "SVQ o XRY",
      "aerolinea": "Nombre Aerolínea",
      "precio": 123,
      "salida": "Viernes HH:MM",
      "regreso": "Lunes HH:MM",
      "clima": "Soleado/Nublado/Lluvia",
      "temperatura": "22°C",
      "coste_alojamiento": "80€/noche",
      "coste_restauracion": "25€/persona",
      "descripcion_destino": "Breve frase atractiva sobre el destino."
    }

    Usa Google Search para encontrar precios reales y clima actual.
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const text = response.text || "";
    // Extraer JSON si el modelo lo rodea con markdown
    const jsonMatch = text.match(/\[[\s\S]*\]/);
    if (jsonMatch) {
      return {
        flights: JSON.parse(jsonMatch[0]) as any[],
        sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
      };
    }
    
    throw new Error("Formato de respuesta no válido");
  } catch (error) {
    console.error("Error fetching escapes:", error);
    throw error;
  }
}
