
export interface FlightOption {
  destino: string;
  origen: string;
  aerolinea: string;
  precio: number;
  salida: string;
  regreso: string;
  clima: string;
  temperatura: string;
  coste_alojamiento: string;
  coste_restauracion: string;
  descripcion_destino: string;
}

export interface SearchState {
  loading: boolean;
  results: FlightOption[];
  error: string | null;
  lastUpdated: string;
  targetWeekend: string;
}
